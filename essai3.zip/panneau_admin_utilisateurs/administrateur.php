<?php
session_start();
// Vérifier si l'utilisateur est connecté comme administrateur
$isAdmin = true; // À remplacer par ta logique d'authentification réelle

if (!$isAdmin) {
    header("Location: index.php");
    exit();
}

$pageTitle = "Admin - Gestion des annonces";

?>

<section class="admin-page">
    <div class="container">
        <h1>Panneau d'administration</h1>
        <p>Bienvenue, administrateur. Gérez les annonces ci-dessous.</p>

        <div class="admin-actions">
            <a href="ajouter_annonce.php" class="btn btn-primary">➕ Ajouter une annonce</a>
        </div>

        <div class="annonces-admin">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Titre</th>
                        <th>Prix</th>
                        <th>Localisation</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Exemple statique (à remplacer par les données de la BDD)
                    for ($i = 1; $i <= 5; $i++): ?>
                        <tr>
                            <td><?= $i ?></td>
                            <td><img src="assets/images/animal<?= $i ?>.jpg" width="50" alt="Animal"></td>
                            <td>Mouton Ladoum <?= $i ?></td>
                            <td>250.000 FCFA</td>
                            <td>Dakar</td>
                            <td>
                                <a href="modifier_annonce.php?id=<?= $i ?>" class="btn btn-sm btn-warning">Modifier</a>
                                <a href="supprimer_annonce.php?id=<?= $i ?>" class="btn btn-sm btn-danger">Supprimer</a>
                            </td>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<style>
    .admin-page {
        padding: 20px;
        background-color: #f9f9f9;
    }
    .admin-actions {
        margin-bottom: 20px;
    }
    .admin-table {
        width: 100%;
        border-collapse: collapse;
    }
    .admin-table th, .admin-table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: center;
    }
    .admin-table th {
        background-color:rgb(242, 242, 242);
    }
    .btn-primary {
        background-color: rgb(9, 255, 0);
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
    }
    .btn-warning {
        background-color: rgba(55, 221, 55, 0.46);
        color: white;
        padding: 5px 10px;
        text-decoration: none;
        border-radius: 5px;
    }
    .admin-page {
        padding: 20px;
        background-color: #f9f9f9;
    }
    .admin-actions {
        margin-bottom: 20px;
    }
    .admin-table {
        width: 100%;
        border-collapse: collapse;
    }
    .admin-table th, .admin-table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: center;
    }
    .admin-table th {
        background-color:rgba(14, 221, 14, 0.84);
    }
    .btn-primary {
        background-color:rgb(9, 255, 0);
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
    }
    .btn-warning {
        background-color: rgba(55, 221, 55, 0.46);
        color: white;
        padding: 3px 7px;
        text-decoration: none;
        border-radius: 5px;
    }
    .btn-danger {
        background-color: rgb(255, 0, 0);
        color: white;
        padding: 0px 20px;
        text-decoration: none;
        border-radius: 0px;
    }
</style>
