<?php
$utilisateurs = [
    ['id' => 1, 'nom' => 'Coumba Diallo', 'email' => 'coumba@example.com', 'role' => 'admin'],
    ['id' => 2, 'nom' => 'Fatou Ndiaye', 'email' => 'fatou@example.com', 'role' => 'utilisateur'],
    ['id' => 3, 'nom' => 'Moussa Ba', 'email' => 'moussa@example.com', 'role' => 'utilisateur'],
];
