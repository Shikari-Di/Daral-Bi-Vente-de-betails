<?php
// Informations de connexion à la base de données
$servername = "localhost";  // Ou l'adresse IP de ton serveur de base de données
$username = "root";         // Nom d'utilisateur de la base de données (par défaut c'est "root" sur WAMP/XAMPP)
$password = "";             // Le mot de passe pour l'utilisateur (vide par défaut sur WAMP/XAMPP)
$dbname = "daral_bi";       // Le nom de la base de données

// Créer la connexion
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Vérifier la connexion
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
