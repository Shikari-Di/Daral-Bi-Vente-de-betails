<?php






if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = $_POST['titre'];
    $prix = $_POST['prix'];
    $localisation = $_POST['localisation'];


}
?>

<section class="modifier-annonce">
    <div class="container">
        <h1>Modifier l'annonce</h1>
        <form method="post">
            <input type="text" name="titre" value="titre" required><br>
            <input type="number" name="prix" value="Prix" required><br>
            <input type="text" name="localisation" value="localisation" required><br>
            <button type="submit">Enregistrer</button>
        </form>
        <a href="admin.php">⬅ Retour</a>
    </div>
</section>


<style>
    .modifier-annonce {
        padding: 20px;
        background-color: #f9f9f9;
    }
    .modifier-annonce form {
        display: flex;
        flex-direction: column;
    }
    .modifier-annonce input, .modifier-annonce button {
        margin-bottom: 10px;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #ccc;
    }  
    .modifier-annonce button {
        background-color: rgb(0, 255, 42);
        color: white;
        border: none;
        cursor: pointer;
    }
    .modifier-annonce button:hover {
        background-color: rgb(0, 143, 179);
    }
    .modifier-annonce a {
        display: inline-block;
        margin-top: 10px;
        text-decoration: none;
        color: rgb(0, 255, 179);
    }
    .modifier-annonce a:hover {
        text-decoration: underline;
        color: rgb(0, 174, 255);
        font-size: 30px;
    }
    .modifier-annonce h1 {
        color: #333;
        text-align: center;
    }
    .modifier-annonce .container {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
</style>     