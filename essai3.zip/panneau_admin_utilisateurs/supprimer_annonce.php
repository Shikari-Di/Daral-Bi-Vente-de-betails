<?php
// Inclure la connexion à la base de données
include 'db.php'; 

// Vérifier si l'ID de l'annonce est fourni
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Supprimer l'annonce
    $sql = "DELETE FROM annonces WHERE id = $id";

    if (mysqli_query($conn, $sql)) {
        echo "<p>Annonce supprimée avec succès.</p>";
    } else {
        echo "<p>Erreur lors de la suppression : " . mysqli_error($conn) . "</p>";
    }
} else {
    echo "<p>ID d'annonce manquant.</p>";
}

// Fermer la connexion
mysqli_close($conn);
?>

<!-- Bouton Retour -->
<a href="admin.php" class="btn-retour"><i class="fas fa-arrow-left"></i> Retour</a>

<!-- Un peu de style -->
<style>
    body {
        font-family: Arial, sans-serif;
        padding: 20px;
        background-color: rgba(138, 207, 147, 0.01);
    }
    p {
        font-size: 25px;
        color: #333;
        text-align: center;
        margin-top: 20px;
        font-weight: bold;
        color: rgb(0, 255, 179);



    }
    .btn-retour {
        display: inline-block;
        margin-top: 20px;
        padding: 10px 15px;
        background-color: #28a745;
        color: white;
        text-decoration: none;
        border-radius: 4px;
        font-weight: bold;
        text-align: center;
    }
    .btn-retour:hover {
        background-color:rgb(16, 207, 89);
        text-decoration: black;
        font-size: 40px;
        font-weight: bold;
        color: rgba(214, 67, 99, 0.61);    


    }
    .fas {
        margin-right: 5px;
    }


</style>
